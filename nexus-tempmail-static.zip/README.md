# NEXUS TempMail (Static)

Bản này **không còn Flask/backend** — toàn bộ là HTML/CSS/JS tĩnh, gọi thẳng
API `https://cheapluxurymail.xyz` từ trình duyệt. Chạy được trực tiếp trên
GitHub Pages.

## Cách đưa lên GitHub Pages

1. Tạo repo mới trên GitHub, ví dụ `nexus-tempmail`.
2. Đẩy toàn bộ nội dung thư mục này lên repo (nhánh `main`):
   ```bash
   git init
   git add .
   git commit -m "Static NEXUS TempMail"
   git branch -M main
   git remote add origin https://github.com/<user>/<repo>.git
   git push -u origin main
   ```
3. Vào repo trên GitHub → **Settings → Pages**.
4. Ở mục "Build and deployment" chọn **Source: Deploy from a branch**,
   Branch: `main`, thư mục `/ (root)` → **Save**.
5. Sau khoảng 1 phút, trang sẽ có ở:
   `https://<user>.github.io/<repo>/`

## Lưu ý quan trọng

- **Dữ liệu (email đã tạo/đã lưu) chỉ nằm trong `localStorage` của trình
  duyệt** — không còn file JSON phía server. Mỗi máy/trình duyệt sẽ có danh
  sách riêng, xóa cache/trình duyệt sẽ mất danh sách này.
- **Theo dõi hộp thư (Monitor)** trước đây dùng WebSocket qua server nền,
  giờ dùng `setInterval` gọi lại API định kỳ ngay trong tab trình duyệt —
  nên chỉ hoạt động khi tab đang mở.
- **CORS**: API `cheapluxurymail.xyz` vốn dùng cho server gọi server, không
  chắc có bật CORS cho request từ trình duyệt. Nếu mở trang lên mà các nút
  báo lỗi "Lỗi kết nối" liên tục, mở DevTools (F12) → tab Console/Network để
  kiểm tra — nếu thấy lỗi CORS thì bắt buộc phải có một proxy nhỏ (Cloudflare
  Worker, Vercel Edge Function...) đứng giữa, vì trình duyệt tĩnh không thể
  tự vượt CORS.
