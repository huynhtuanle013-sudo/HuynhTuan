// ─────────────────────────────────────────────
//  CẤU HÌNH — Gọi thẳng API từ trình duyệt (không còn backend Flask)
// ─────────────────────────────────────────────
const API_BASE = "https://cheapluxurymail.xyz";
const SAVE_KEY = "nexus_saved_mails";
const CURRENT_KEY = "nexus_current_mail";

let currentEmail = null;
let currentPassword = null;
let isMonitoring = false;
let monitorTimer = null;
let monitorSeenIds = new Set();
let cachedDomains = [];

// ─────────────────────────────────────────────
//  LƯU TRỮ CỤC BỘ (thay cho session/file phía server)
// ─────────────────────────────────────────────

function loadSavedMails() {
    try {
        return JSON.parse(localStorage.getItem(SAVE_KEY) || '{}');
    } catch (e) {
        return {};
    }
}

function persistSavedMails(saved) {
    localStorage.setItem(SAVE_KEY, JSON.stringify(saved));
}

function rememberMail(email, password) {
    const saved = loadSavedMails();
    saved[email] = {
        password,
        created_at: saved[email]?.created_at || new Date().toISOString(),
        last_used: new Date().toISOString(),
    };
    persistSavedMails(saved);
}

// ─────────────────────────────────────────────
//  GỌI API TEMPMAIL TRỰC TIẾP
// ─────────────────────────────────────────────

async function apiGet(endpoint) {
    try {
        const res = await fetch(`${API_BASE}${endpoint}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' }
        });
        return res;
    } catch (e) {
        return null;
    }
}

async function apiPost(endpoint, body) {
    try {
        const res = await fetch(`${API_BASE}${endpoint}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify(body)
        });
        return res;
    } catch (e) {
        return null;
    }
}

async function loadDomains() {
    if (cachedDomains.length) return cachedDomains;
    const res = await apiGet('/domains');
    if (res && res.ok) {
        try {
            const data = await res.json();
            cachedDomains = data?.data?.domains || [];
        } catch (e) { /* ignore */ }
    }
    if (!cachedDomains.length) {
        cachedDomains = ["cheapluxury.eu", "tempmail.com", "example.com"];
    }
    return cachedDomains;
}

function randomString(len, chars) {
    let out = '';
    for (let i = 0; i < len; i++) out += chars[Math.floor(Math.random() * chars.length)];
    return out;
}

async function apiCreateEmail() {
    const res = await apiGet('/random_email');
    if (res && res.ok) {
        try {
            const data = await res.json();
            if (data.response_code === 200) {
                const email = data?.data?.email;
                const password = data?.data?.password;
                if (email && password) return { email, password };
            }
        } catch (e) { /* fall through to fallback */ }
    }

    // Fallback: tự sinh địa chỉ rồi đăng ký
    const domains = await loadDomains();
    if (domains.length) {
        const local = randomString(10, 'abcdefghijklmnopqrstuvwxyz0123456789');
        const domain = domains[Math.floor(Math.random() * domains.length)];
        const email = `${local}@${domain}`;
        const password = randomString(12, 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789');
        const reg = await apiPost('/register', { email, password });
        if (reg && reg.status === 201) {
            return { email, password };
        }
    }
    return null;
}

async function apiCheckMailbox(email, password) {
    const res = await apiPost('/email/get', { email, password });
    if (!res) return { success: false, error: 'Không thể kết nối đến server (có thể do CORS hoặc mạng)' };
    if (res.status === 401) return { success: false, error: 'Email đã hết hạn hoặc sai mật khẩu' };
    try {
        const data = await res.json();
        if (data.response_code === 200) {
            return { success: true, emails: data?.data?.emails || [] };
        }
        return { success: false, error: data.message || 'Lỗi không xác định' };
    } catch (e) {
        return { success: false, error: 'Lỗi parse dữ liệu' };
    }
}

async function apiReadMail(email, password, messageId) {
    const res = await apiPost('/email/view', { email, password, message_id: messageId });
    if (!res) return { success: false, error: 'Không thể kết nối đến server' };
    try {
        const data = await res.json();
        if (data.response_code === 200) {
            return { success: true, email: data?.data?.email || {} };
        }
        return { success: false, error: data.message || 'Lỗi không xác định' };
    } catch (e) {
        return { success: false, error: 'Lỗi parse dữ liệu' };
    }
}

async function apiRecoverEmail(email) {
    const saved = loadSavedMails();
    if (!saved[email]) return { success: false, error: 'Email không tồn tại trong danh sách' };
    const password = saved[email].password;
    const res = await apiPost('/login', { email, password });
    if (res && res.status === 200) {
        try {
            const data = await res.json();
            if (data.response_code === 200) {
                saved[email].last_used = new Date().toISOString();
                persistSavedMails(saved);
                return { success: true, password };
            }
        } catch (e) { /* fall through */ }
    }
    return { success: false, error: 'Email đã hết hạn' };
}

// ─────────────────────────────────────────────
//  TOAST NOTIFICATIONS
// ─────────────────────────────────────────────

function showToast(message, type = 'info') {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = `toast ${type}`;
    toast.style.display = 'block';
    clearTimeout(toast._timeout);
    toast._timeout = setTimeout(() => {
        toast.style.display = 'none';
    }, 4000);
}

// ─────────────────────────────────────────────
//  LOADING
// ─────────────────────────────────────────────

function showLoading(show = true) {
    document.getElementById('loading').style.display = show ? 'flex' : 'none';
}

// ─────────────────────────────────────────────
//  MODAL
// ─────────────────────────────────────────────

function openModal(html) {
    document.getElementById('modalBody').innerHTML = html;
    document.getElementById('modal').style.display = 'flex';
}

function closeModal() {
    document.getElementById('modal').style.display = 'none';
}

// ─────────────────────────────────────────────
//  CURRENT EMAIL
// ─────────────────────────────────────────────

function updateCurrentEmail(email, password) {
    currentEmail = email;
    currentPassword = password;
    const display = document.getElementById('currentEmailDisplay');
    if (email && password) {
        display.style.display = 'block';
        document.getElementById('currentEmail').textContent = email;
        document.getElementById('currentPassword').textContent = password;
        localStorage.setItem(CURRENT_KEY, JSON.stringify({ email, password }));
    } else {
        display.style.display = 'none';
        localStorage.removeItem(CURRENT_KEY);
    }
}

function clearCurrentEmail() {
    updateCurrentEmail(null, null);
    document.getElementById('mailList').style.display = 'none';
    document.getElementById('emptyState').style.display = 'block';
}

// ─────────────────────────────────────────────
//  CREATE EMAIL
// ─────────────────────────────────────────────

async function createEmail() {
    showLoading(true);
    try {
        const result = await apiCreateEmail();
        if (result) {
            rememberMail(result.email, result.password);
            updateCurrentEmail(result.email, result.password);
            showToast(`Đã tạo email: ${result.email}`, 'success');
            await checkMailbox();
        } else {
            showToast('Không thể tạo email', 'error');
        }
    } catch (error) {
        showToast('Lỗi kết nối', 'error');
    }
    showLoading(false);
}

// ─────────────────────────────────────────────
//  CHECK MAILBOX
// ─────────────────────────────────────────────

async function checkMailbox() {
    const email = currentEmail || document.getElementById('currentEmail')?.textContent;
    const password = currentPassword || document.getElementById('currentPassword')?.textContent;

    if (!email || !password) {
        showToast('Chưa có email nào được chọn', 'warning');
        return;
    }

    showLoading(true);
    try {
        const data = await apiCheckMailbox(email, password);
        if (data.success) {
            renderMailList(data.emails, email);
            showToast(`Có ${data.emails.length} thư`, 'info');
        } else {
            showToast(data.error || 'Không thể kiểm tra hộp thư', 'error');
        }
    } catch (error) {
        showToast('Lỗi kết nối', 'error');
    }
    showLoading(false);
}

function renderMailList(emails, email) {
    const container = document.getElementById('mailList');
    const empty = document.getElementById('emptyState');

    if (!emails || emails.length === 0) {
        container.style.display = 'none';
        empty.style.display = 'block';
        return;
    }

    empty.style.display = 'none';
    container.style.display = 'block';

    let html = `
        <div class="mailbox-header">
            <h3><i class="fas fa-inbox"></i> Hộp thư: <span id="mailboxEmail">${email}</span></h3>
            <span class="mail-count">${emails.length} thư</span>
        </div>
        <div class="mail-list">
    `;

    emails.forEach((mail, index) => {
        const mid = mail.id || mail.message_id || index;
        const sender = mail.from_addr || mail.from || '?';
        const subject = mail.subject || '(không có tiêu đề)';
        const date = mail.date || '';
        const flags = mail.flags || [];
        const isRead = flags.includes('seen');
        const body = mail.body_text || mail.body || '';
        const preview = body ? body.substring(0, 80).replace(/\n/g, ' ').trim() : '';

        html += `
            <div class="mail-item ${isRead ? 'read' : 'unread'}" onclick="readMail('${mid}')">
                <div class="mail-sender">${sender}</div>
                <div class="mail-subject">${subject}</div>
                <div style="display:flex; justify-content:space-between; align-items:center; margin-top:4px;">
                    <span class="mail-date">${date}</span>
                    ${!isRead ? '<span class="mail-badge">Mới</span>' : ''}
                </div>
                ${preview ? `<div style="font-size:13px; opacity:0.7; margin-top:4px;">${preview}...</div>` : ''}
            </div>
        `;
    });

    html += '</div>';
    container.innerHTML = html;
}

// ─────────────────────────────────────────────
//  READ MAIL
// ─────────────────────────────────────────────

async function readMail(messageId) {
    const email = currentEmail || document.getElementById('currentEmail')?.textContent;
    const password = currentPassword || document.getElementById('currentPassword')?.textContent;

    if (!email || !password) {
        showToast('Chưa có email', 'warning');
        return;
    }

    showLoading(true);
    try {
        const data = await apiReadMail(email, password, messageId);
        if (data.success) {
            const mail = data.email;
            const body = mail.body_text || mail.body || '(trống)';
            const cleanBody = body.replace(/<[^>]+>/g, '');

            const html = `
                <h3><i class="fas fa-envelope"></i> ${mail.subject || '(không có tiêu đề)'}</h3>
                <hr style="border-color: rgba(255,255,255,0.1); margin: 15px 0;">
                <p><strong>Từ:</strong> ${mail.from_addr || mail.from || '?'}</p>
                <p><strong>Ngày:</strong> ${mail.date || '?'}</p>
                <hr style="border-color: rgba(255,255,255,0.1); margin: 15px 0;">
                <div style="white-space: pre-wrap; word-break: break-word;">${cleanBody}</div>
                <hr style="border-color: rgba(255,255,255,0.1); margin: 15px 0;">
                <button class="btn btn-primary" onclick="closeModal()">Đóng</button>
            `;
            openModal(html);
        } else {
            showToast(data.error || 'Không thể đọc thư', 'error');
        }
    } catch (error) {
        showToast('Lỗi kết nối', 'error');
    }
    showLoading(false);
}

// ─────────────────────────────────────────────
//  SAVED EMAILS
// ─────────────────────────────────────────────

async function showSavedEmails() {
    showLoading(true);
    try {
        const saved = loadSavedMails();
        const emails = Object.keys(saved);

        let html = `<h3><i class="fas fa-history"></i> Email đã lưu</h3><hr style="border-color: rgba(255,255,255,0.1); margin: 15px 0;"><ul class="saved-list">`;

        if (emails.length === 0) {
            html += `<li style="text-align:center; opacity:0.6;">Chưa có email nào được lưu</li>`;
        } else {
            emails.forEach(email => {
                html += `
                    <li>
                        <span class="email-text"><i class="fas fa-envelope"></i> ${email}</span>
                        <span class="email-actions">
                            <button class="btn btn-primary btn-sm" onclick="recoverEmail('${email}')">
                                <i class="fas fa-undo"></i> Dùng lại
                            </button>
                            <button class="btn btn-danger btn-sm" onclick="deleteEmail('${email}')">
                                <i class="fas fa-trash"></i>
                            </button>
                        </span>
                    </li>
                `;
            });
        }
        html += '</ul><button class="btn btn-primary" onclick="closeModal()">Đóng</button>';
        openModal(html);
    } catch (error) {
        showToast('Lỗi kết nối', 'error');
    }
    showLoading(false);
}

async function recoverEmail(email) {
    showLoading(true);
    try {
        const data = await apiRecoverEmail(email);
        if (data.success) {
            updateCurrentEmail(email, data.password);
            showToast(`Khôi phục: ${email}`, 'success');
            closeModal();
            await checkMailbox();
        } else {
            showToast(data.error || 'Không thể khôi phục', 'error');
        }
    } catch (error) {
        showToast('Lỗi kết nối', 'error');
    }
    showLoading(false);
}

async function deleteEmail(email) {
    if (!confirm(`Xóa email ${email}?`)) return;

    showLoading(true);
    try {
        const saved = loadSavedMails();
        if (saved[email]) {
            delete saved[email];
            persistSavedMails(saved);
            showToast(`Đã xóa ${email}`, 'success');
            if (currentEmail === email) {
                clearCurrentEmail();
            }
            await showSavedEmails();
        } else {
            showToast('Email không tồn tại', 'error');
        }
    } catch (error) {
        showToast('Lỗi kết nối', 'error');
    }
    showLoading(false);
}

// ─────────────────────────────────────────────
//  MONITOR (polling trực tiếp từ trình duyệt, thay cho WebSocket)
// ─────────────────────────────────────────────

function showMonitor() {
    const email = currentEmail || document.getElementById('currentEmail')?.textContent;
    const password = currentPassword || document.getElementById('currentPassword')?.textContent;

    if (!email || !password) {
        showToast('Chưa có email được chọn', 'warning');
        return;
    }

    const html = `
        <h3><i class="fas fa-sync-alt"></i> Theo dõi hộp thư</h3>
        <p style="margin: 10px 0; opacity:0.7;">Đang theo dõi: <strong>${email}</strong></p>
        <div class="monitor-controls">
            <label>Khoảng cách (giây):</label>
            <input type="number" id="monitorInterval" value="10" min="3" max="60">
            <button class="btn btn-success" id="monitorStartBtn" onclick="startMonitor()">
                <i class="fas fa-play"></i> Bắt đầu
            </button>
            <button class="btn btn-danger" id="monitorStopBtn" onclick="stopMonitor()" style="display:none;">
                <i class="fas fa-stop"></i> Dừng
            </button>
            <span class="monitor-status inactive" id="monitorStatus">Đã dừng</span>
        </div>
        <div id="monitorLog" style="max-height:300px; overflow-y:auto; background:rgba(0,0,0,0.3); border-radius:8px; padding:10px; margin-top:10px; font-size:13px;">
            <div style="opacity:0.5;">Chưa có thư mới...</div>
        </div>
        <hr style="border-color: rgba(255,255,255,0.1); margin: 15px 0;">
        <button class="btn btn-primary" onclick="closeModal()">Đóng</button>
    `;
    openModal(html);
}

async function monitorTick(email, password) {
    const data = await apiCheckMailbox(email, password);
    const log = document.getElementById('monitorLog');
    if (!log) return; // modal closed

    if (!data.success) {
        log.innerHTML += `<div style="color: #e17055; padding: 5px;">⚠ ${data.error}</div>`;
        showToast(data.error, 'error');
        stopMonitor();
        return;
    }

    const newEmails = [];
    (data.emails || []).forEach(mail => {
        const mid = String(mail.id || mail.message_id || JSON.stringify(mail));
        if (!monitorSeenIds.has(mid)) {
            monitorSeenIds.add(mid);
            newEmails.push(mail);
        }
    });

    if (newEmails.length) {
        const time = new Date().toLocaleTimeString();
        newEmails.forEach(mail => {
            const sender = mail.from_addr || mail.from || '?';
            const subject = mail.subject || '(không có tiêu đề)';
            log.innerHTML += `
                <div style="padding: 8px; background: rgba(108,92,231,0.1); border-radius: 6px; margin: 5px 0; border-left: 3px solid #fdcb6e;">
                    <strong style="color: #74b9ff;">[${time}]</strong>
                    <span style="color: #fdcb6e;">●</span>
                    <strong>${sender}</strong> — ${subject}
                    <button class="btn btn-primary btn-sm" onclick="closeModal();readMail('${mail.id || mail.message_id}')" style="float:right; font-size:10px;">
                        <i class="fas fa-eye"></i> Xem
                    </button>
                </div>
            `;
            log.scrollTop = log.scrollHeight;
        });
        showToast(`📬 ${newEmails.length} thư mới!`, 'success');
    }
}

function startMonitor() {
    const email = currentEmail || document.getElementById('currentEmail')?.textContent;
    const password = currentPassword || document.getElementById('currentPassword')?.textContent;
    const interval = parseInt(document.getElementById('monitorInterval').value) || 10;

    if (!email || !password) {
        showToast('Chưa có email', 'warning');
        return;
    }

    if (isMonitoring) {
        stopMonitor();
    }

    isMonitoring = true;
    monitorSeenIds = new Set();
    document.getElementById('monitorStartBtn').style.display = 'none';
    document.getElementById('monitorStopBtn').style.display = 'inline-flex';
    document.getElementById('monitorStatus').className = 'monitor-status active';
    document.getElementById('monitorStatus').textContent = 'Đang theo dõi...';
    document.getElementById('monitorLog').innerHTML = `<div style="color: #00b894;">✓ Đang theo dõi ${email} (mỗi ${interval}s)</div>`;

    monitorTick(email, password);
    monitorTimer = setInterval(() => monitorTick(email, password), interval * 1000);
}

function stopMonitor() {
    isMonitoring = false;
    if (monitorTimer) {
        clearInterval(monitorTimer);
        monitorTimer = null;
    }
    const startBtn = document.getElementById('monitorStartBtn');
    const stopBtn = document.getElementById('monitorStopBtn');
    const status = document.getElementById('monitorStatus');
    const log = document.getElementById('monitorLog');
    if (startBtn) startBtn.style.display = 'inline-flex';
    if (stopBtn) stopBtn.style.display = 'none';
    if (status) {
        status.className = 'monitor-status inactive';
        status.textContent = 'Đã dừng';
    }
    if (log) log.innerHTML += `<div style="color: #fdcb6e;">⏹ Đã dừng theo dõi</div>`;
}

// ─────────────────────────────────────────────
//  INIT
// ─────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
    // Khôi phục email hiện tại từ lần trước (lưu trong trình duyệt)
    try {
        const raw = localStorage.getItem(CURRENT_KEY);
        if (raw) {
            const { email, password } = JSON.parse(raw);
            if (email && password) {
                updateCurrentEmail(email, password);
            }
        }
    } catch (e) { /* ignore */ }
});

// Đóng modal khi click outside; dừng monitor khi đóng modal đang theo dõi
document.getElementById('modal').addEventListener('click', (e) => {
    if (e.target === e.currentTarget) {
        if (isMonitoring) stopMonitor();
        closeModal();
    }
});

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        if (isMonitoring) stopMonitor();
        closeModal();
    }
});
